#pragma once
ref class AB
{
public:
	AB(void);
};

