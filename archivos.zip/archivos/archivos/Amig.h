#pragma once
ref class Amig
{
public:
	Amig(void);
};

