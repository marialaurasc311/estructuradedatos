#include "stdafx.h"
#include<iostream>
#include<stdlib.h> //Funcion para borrar todo lo que esta en pantalla
#include <fstream>

using namespace std;

struct CLIENTE{
	char cedula[8];
	char nombre[30];
	char telefono[7];
};
void agregarCliente(){
	ofstream archivoGuardar("clientes.txt",ios::app); //funcion constructora
	struct CLIENTE cliente;
	cin.ignore();

		cout<<"Ingrese la cedula del nuevo cliente: ";
		cin.getline(cliente.cedula,8);
		cout<<"Ingrese el nombre del nuevo cliente: ";
		cin.getline(cliente.nombre,30);
		cout<<"Ingrese el telefono del nuevo cliente: ";
		cin.getline(cliente.telefono,7);

	archivoGuardar.write((char *)&cliente,sizeof(cliente)); //La funci�n sizeof calcula el tama�o en bytes de una variable o estructura
	archivoGuardar.close();

void eliminarCliente(){
	struct CLIENTE cliente;
	system("cls");
	verClientes ();
	char bufferCedula[8];
	cin.ignore();
	cout<<"Ingrese la cedula del cliente para eliminar :";
	cin.getline(bufferCedula,8);
	if(clienteLocalizado(bufferCedula)){
		fstream archivoLectura("clientes.txt");
		ofstream archivoEscritura("auxiliar.txt");
		archivoLectura.read((char *) &cliente,sizeof(cliente));
		string cedulaBuscada=bufferCedula;
		while(archivoLectura && !archivoLectura.eof()){
			if (cliente.cedula==cedulaBuscada){

			}
			else{
				archivoEscritura.write((char *) &cliente,sizeof(cliente));
			}
			archivoLectura.read((char *) &cliente,sizeof(cliente));	
		}
		archivoEscritura.close();
		archivoLectura.close();
		remove ("clientes.txt");
		rename ("auxiliar.txt","clientes.txt);
	}
	else{
		cout<<"No se ha encontrado cliente con ese numero de cedula: "<<bufferCedula<<endl;
	}

		

int main(){
	int op;
	do{
		system("cls");
		cin.clear();
		cout<<"-----MENU-----"<<endl;
		cout<<"1. Agregar un cliente: "<<endl;
		cout<<"2. Modificar un cliente: "<<endl;
		cout<<"3. Eliminar un cliente: "<<endl;
		cout<<"4. Ver lista de clientes: "<<endl;
		cout<<"Salir: "<<endl;
		cout<<"Ingrese la opcion: "<<endl;
		cin>>op;
		switch(op){
		case 1:
			agregarCliente();
			system("pause");
			break;
		case 2:
			//modificarCliente();
			system("pause");
			break;
		case 3:
			eliminarCliente();
			system("pause");
			break;
		case 4:
			//verListaClientes();
			system("pause");
			break;
		case 5:
			break;
		default:
			cout<<"Su opcion no es valida. Intente de nuevo "<<endl;
			system("pause");
			break;
		}
	}
}