#include "StdAfx.h"
#include "cuenta.h"

Cuenta::Cuenta(void)
{
}
void Cuenta::Set_Nombre(string nom){
	nombre=nom;
}
void Cuenta::Set_Cuenta(string cuen){
	cuentaa=cuen;
}
void Cuenta::Set_Saldo(double sal){
	saldo=sal;
}
string Cuenta::Get_Nombre(){
	return nombre;
}
string Cuenta::Get_Cuenta(){
	return cuentaa;
}
double Cuenta::Get_Saldo(){
	return saldo;
}
void Cuenta::ingresar(double cantidad){
	saldo=saldo+cantidad;
}
void Cuenta::retirar(double cantidad){
	saldo=saldo-cantidad;
}
	
