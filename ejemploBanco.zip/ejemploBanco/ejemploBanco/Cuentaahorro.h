#pragma once
#include "Cuenta.h"
class Cuentaahorro:public Cuenta
{
private:
	double cuotamantenimiento;
public:
	Cuentaahorro(string nom, string cuen, double sal, double cantidad);
	void Set_CuotaManten(double cantidad);
	double Get_CoutaManten();
	void retirar(double cantidad);
};

