#include "StdAfx.h"
#include "Cuentaahorro.h"


Cuentaahorro::Cuentaahorro(string nom, string cuen, double sal, double cantidad){
}
void Cuentaahorro::Set_CuotaManten(double cantidad){
	cuotamantenimiento=cantidad;
}
double Cuentaahorro::Get_CoutaManten(){
	return cuotamantenimiento;
}
void Cuentaahorro::retirar(double cantidad){
	saldo=saldo-cantidad;
}
